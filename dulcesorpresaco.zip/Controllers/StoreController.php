<?php

/**
 * 
 */
class StoreController /*extends AnotherClass*/
{
	
	public function index()
	{
		echo "hola";
	}
}

?>